# Minha Dieta

App pessoal de acompanhamento da dieta — um único arquivo HTML, sem dependências externas, que funciona como um app simples no navegador (inclusive no iPhone, via "Adicionar à Tela de Início").

## O que tem dentro

- **Hoje**: suplementos do dia e as refeições prescritas pela nutricionista, com opções de troca (swaps) para cada refeição, e um botão para marcar cada uma como feita.
- **Preparo**: checklist de tarefas de preparo semanal (porcionar, fazer sanduíches, etc.), com progresso salvo por semana.
- **Despensa**: referência do que normalmente tem na geladeira/despensa, por categoria.
- **Mais**: regras rápidas (refrigerante, sucos, salada, ceia), rotina diária e um registro de peso.

Tudo o que é marcado (refeições, suplementos, tarefas de preparo, peso) é salvo no `localStorage` do navegador — ou seja, fica guardado no próprio aparelho, por data.

## Como usar localmente

Não precisa de servidor nem de instalação. Basta abrir o arquivo `index.html` em qualquer navegador moderno (Chrome, Safari, Firefox).

## Como publicar com GitHub Pages (link público gratuito)

1. Crie um repositório novo no GitHub e envie estes arquivos (`index.html` e este `README.md`) para a branch `main`.
2. No repositório, vá em **Settings → Pages**.
3. Em "Source", selecione a branch `main` e a pasta `/ (root)`.
4. Salve. Em alguns minutos o GitHub mostra o link público (algo como `https://seu-usuario.github.io/nome-do-repositorio/`).
5. Abra esse link no Safari do iPhone e, no menu de compartilhar, escolha **Adicionar à Tela de Início** — o app passa a abrir com ícone próprio, com tudo clicável.

## Estrutura

```
.
├── index.html   # o app completo (HTML + CSS + JS em um único arquivo)
└── README.md    # este arquivo
```
